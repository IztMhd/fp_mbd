const { Categories } = require("../models");

module.exports = {
    create(createArgs) {
        return Categories.create(createArgs);
    },
    update(id, updateArgs) {
        return Categories.update(updateArgs, {
            where: {
                id,
            }
        });
    },
    delete(id) {
        return Categories.destroy(id);
    },
    find(id) {
        return Categories.findOne({
            where: {
                id,
            },
        });
    },

    findAll(args) {
        return Categories.findAll(args);
    },

    getTotalCategories(args) {
        return Categories.count(args);
    },
}