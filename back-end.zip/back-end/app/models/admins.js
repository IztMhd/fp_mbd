'use strict';
const {
    Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Admins extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
        static associate(models) {
            // define association here
        }
    }
    Admins.init({
        namaAdmin: DataTypes.STRING,
        emailAdmin: {
            type: DataTypes.STRING,
            unique: {
                args: true,
                msg: 'Email already exist'
            },
            validate: {
                isLowercase: true,
                notEmpty: {
                    msg: 'Please input your email'
                },
                isEmail: {
                    msg: 'Email is invalid'
                }
            }
        },
        noHP: DataTypes.STRING,
        userName: DataTypes.STRING,
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        role: {
            type: DataTypes.STRING,
            defaultValue: "user",
        },
        saldo: {
            type: DataTypes.INTEGER,
            defaultValue: null,
        },
    }, {
        sequelize,
        modelName: 'Admins',
    });
    return Admins;
};