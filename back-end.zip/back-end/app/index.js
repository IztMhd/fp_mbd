require('dotenv').config()

const express = require("express");
const morgan = require("morgan");
const path = require("path");
const router = require("../config/routes");
const cors = require('cors')

const publicDir = path.join(__dirname, "../public");
const viewsDir = path.join(__dirname, "./views");
const app = express();

app.locals.moment = require('moment')
    /** Install request logger */
app.use(morgan("dev"));

/** Install JSON request parser */
app.use(express.json());

/** Install View Engine */
app.set("views", viewsDir);
app.set("view engine", "ejs");
app.use(cors());
/** Set Public Directory */
app.use(express.static(publicDir));

app.use('/admin/categories', express.static(path.join(__dirname, '../public')));
app.use('/admin/categories/edit', express.static(path.join(__dirname, '../public')));
app.use('/admin/product', express.static(path.join(__dirname, '../public')));
app.use('/admin/product/edit', express.static(path.join(__dirname, '../public')));

app.use(express.static(path.join(__dirname, '../public')));

/** Install Router */
app.use(router);

module.exports = app;