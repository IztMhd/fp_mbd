const categoriesServices = require("../../../services/categoriesServices");

module.exports = {
    create(req, res) {
        categoriesServices
            .create(req.body)
            .then((category) => {
                res.status(201).json({
                    status: "OK",
                    data: category,
                });
            })
            .catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    list(req, res) {
        categoriesServices
            .list()
            .then(({ data, count }) => {
                res.status(200).json({
                    status: "OK",
                    data: { categories: data },
                    meta: { total: count },
                });
            })
            .catch((err) => {
                res.status(400).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    update(req, res) {
        categoriesServices
            .update(req.params.id, req.body)
            .then(() => {
                res.status(200).json({
                    status: "OK",
                });
            })

        .catch((err) => {
            res.status(422).json({
                status: "FAIL",
                message: err.message,
            });
        });
    },

    delete(req, res) {
        categoriesServices.delete({
                where: {
                    id: req.params.id
                }
            })
            .then(() => {
                res.status(200).json({
                    status: "OK",
                })
            }).catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    show(req, res) {
        categoriesServices
            .get(req.params.id)
            .then((categories) => {
                res.status(200).json({
                    status: "OK",
                    data: categories,
                });
            })
            .catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },



};