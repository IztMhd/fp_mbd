const { Categories } = require('../../../models')

const halamanCategory = async(req, res, next) => {
    try {
        const items = await Categories.findAll()
        res.status(200)
        res.render('homeCategories', {
            title: 'Halaman Index',
            items,
        })
    } catch (error) {
        res.status(404).json({
            message: error.message,
        })
    }
}

const halamanTambahCategory = async(req, res, next) => {
    try {
        res.render('addCategories', {
            title: 'Halaman Index',
        })
    } catch (error) {
        res.status(404).json({
            message: error.message,
        })
    }
}

const createCategory = async(req, res) => {

    try {

        const { nama } = req.body
        const newCategory = await Categories.create({
            nama
        })
        res.redirect('/admin/categories')
    } catch (error) {
        res.status(400).json({
            message: error.message,
        })
    }
}

const updatedCategory = async(req, res) => {
    try {
        const { nama } = req.body
        const id = req.params.id
        const newCategory = await Categories.create({
            nama
        }, {
            where: {
                id
            }
        })
        res.redirect('/admin/categories')
    } catch (error) {
        res.status(400).json({
            message: error.message,
        })
    }
}
const halamanEditCategory = async(req, res, next) => {
    try {
        const item = await Categories.findByPk(req.params.id)
        res.render('editCategories', {
            item,
            title: 'Halaman Index',
        })
    } catch (error) {
        res.status(404).json({
            message: error.message,
        })
    }
}
module.exports = {
    halamanCategory,
    halamanTambahCategory,
    createCategory,
    updatedCategory,
    halamanEditCategory,
}