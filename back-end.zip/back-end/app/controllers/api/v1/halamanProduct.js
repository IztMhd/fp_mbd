const { Product } = require('../../../models')

const halamanProduct = async(req, res, next) => {
    try {
        const items = await Product.findAll()
        res.status(200)
        res.render('homeProduct', {
            title: 'Halaman Index',
            items,
        })
    } catch (error) {
        res.status(404).json({
            message: error.message,
        })
    }
}

const halamanTambahProduct = async(req, res, next) => {
    try {
        res.render('addProduct', {
            title: 'Halaman Index',
        })
    } catch (error) {
        res.status(404).json({
            message: error.message,
        })
    }
}

const createProduct = async(req, res) => {

    try {
        const newProduct = await Product.create(req.body)
        res.redirect('/admin/product')
    } catch (error) {
        res.status(400).json({
            message: error.message,
        })
    }
}

const updatedProduct = async(req, res) => {
    try {
        const id = req.params.id
        const newProduct = await Product.create(
            req.body, {
                where: {
                    id
                }
            })
        res.redirect('/admin/product')
    } catch (error) {
        res.status(400).json({
            message: error.message,
        })
    }
}
const halamanEditProduct = async(req, res, next) => {
    try {
        const item = await Product.findByPk(req.params.id)
        res.render('editProduct', {
            item,
            title: 'Halaman Index',
        })
    } catch (error) {
        res.status(404).json({
            message: error.message,
        })
    }
}
module.exports = {
    halamanProduct,
    halamanTambahProduct,
    createProduct,
    updatedProduct,
    halamanEditProduct,
}