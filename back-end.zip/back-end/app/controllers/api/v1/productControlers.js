const categoriesServices = require("../../../services/categoriesServices");
const productServices = require("../../../services/productServices");

module.exports = {
    create(req, res) {
        productServices
            .create(req.body)
            .then((product) => {
                res.status(201).json({
                    status: "OK",
                    data: product,
                });
            })
            .catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    list(req, res) {
        productServices
            .list()
            .then(({ data, count }) => {
                res.status(200).json({
                    status: "OK",
                    data: { product: data },
                    meta: { total: count },
                });
            })
            .catch((err) => {
                res.status(400).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    update(req, res) {
        productServices
            .update(req.params.id, req.body)
            .then(() => {
                res.status(200).json({
                    status: "OK",
                });
            })
            .catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },

    delete(req, res) {
        productServices.delete({
                where: {
                    id: req.params.id
                }
            })
            .then(() => {
                res.status(200).json({
                    status: "OK",
                })
            }).catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    showProduct(req, res) {
        productServices
            .get(req.params.id)
            .then((product) => {
                res.status(200).json({
                    status: "OK",
                    data: product,
                });
            })
            .catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    showProductCategories(req, res) {
        categoriesServices
            .get({
                where: {
                    id: req.params.categoryId,
                }
            })
            .populate("products")
            .then((categories) => {
                res.status(200).json({
                    status: "OK",
                    data: categories[0].products,
                });
            })
            .catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },


};