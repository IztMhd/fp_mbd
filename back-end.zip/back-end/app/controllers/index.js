const api = require("./api");
const main = require("./main");

module.exports = {
    api,
    main,
};