const Product = require("../repositories/Product");

module.exports = {
    create(requestBody) {
        return Product.create(requestBody);
    },

    update(id, requestBody) {
        return Product.update(id, requestBody);
    },

    delete(id) {
        return Product.delete(id);
    },

    async list(args) {
        try {
            const product = await Product.findAll(args);
            const productCount = await Product.getTotalProduct(args);

            return {
                data: product,
                count: productCount,
            };
        } catch (err) {
            throw err;
        }
    },

    get(id) {
        return Product.find(id);
    },
};