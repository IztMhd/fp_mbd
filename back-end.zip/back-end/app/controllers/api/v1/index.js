const adminController = require('./adminController');
const categoriesControllers = require('./categoriesControllers');
const productControllers = require('./productControlers');
const ordersControllers = require('./ordersControllers');
const halamanCategory = require('./halamanCategories');
const halamanProduct = require('./halamanProduct');
const halamaniSign = require('./halamaniSign');

module.exports = {
    adminController,
    categoriesControllers,
    productControllers,
    ordersControllers,
    halamanCategory,
    halamanProduct,
    halamaniSign,
}