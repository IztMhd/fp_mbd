const { Admins } = require("../models");

module.exports = {
    create(createArgs) {
        return Admins.create(createArgs);
    },
    login(emailAdmin) {
        return Admins.findOne({
            where: { emailAdmin },
        })
    },

    update(id, updateArgs) {
        return Admins.update(updateArgs, {
            where: {
                id,
            },
        });
    },

    delete(id) {
        return Admins.destroy(id);
    },

    find(id) {
        return Admins.findByPk(id);
    },

    findAll() {
        return Admins.findAll();
    },

    getTotalUser() {
        return Admins.count();
    },

}