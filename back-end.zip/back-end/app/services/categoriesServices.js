const Categories = require("../repositories/Categories");

module.exports = {
    create(requestBody) {
        return Categories.create(requestBody);
    },

    update(id, requestBody) {
        return Categories.update(id, requestBody);
    },

    delete(id) {
        return Categories.delete(id);
    },

    async list(args) {
        try {
            const categories = await Categories.findAll(args);
            const categoriesCount = await Categories.getTotalCategories(args);

            return {
                data: categories,
                count: categoriesCount,
            };
        } catch (err) {
            throw err;
        }
    },

    get(id) {
        return Categories.find(id);
    },
};