const { Orders } = require("../models");

module.exports = {
    create(createArgs) {
        return Orders.create(createArgs);
    },
    update(id, updateArgs) {
        return Orders.update(updateArgs, {
            where: {
                id,
            }
        });
    },
    delete(id) {
        return Orders.destroy({
            where: {
                id,
            }
        });
    },
    find(id) {
        return Orders.findOne({
            where: {
                id,
            },
        });
    },

    findAll(args) {
        return Orders.findAll(args);
    },

    getTotalOrders(args) {
        return Orders.count(args);
    },
}