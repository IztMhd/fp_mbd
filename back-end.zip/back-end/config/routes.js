const express = require("express");
const controllers = require("../app/controllers")
const apiRouter = express.Router();

apiRouter.get("/login",
    controllers.api.v1.adminController.halamanLogin
);

apiRouter.post("/login",
    controllers.api.v1.halamaniSign.login
);


apiRouter.get("/register",
    controllers.api.v1.adminController.halamanRegister
);

apiRouter.get("/dashboard", controllers.api.v1.adminController.homeView);

apiRouter.get("/", controllers.api.v1.adminController.halamanAwal);

apiRouter.get("/admin/categories", controllers.api.v1.halamanCategory.halamanCategory);

apiRouter.get("/admin/categories/add", controllers.api.v1.halamanCategory.halamanTambahCategory);

apiRouter.post("/admin/categories/add", controllers.api.v1.halamanCategory.createCategory);

apiRouter.get("/admin/categories/edit/:id", controllers.api.v1.halamanCategory.halamanEditCategory);

apiRouter.post("/admin/categories/edit/:id", controllers.api.v1.halamanCategory.updatedCategory);

apiRouter.get("/admin/product", controllers.api.v1.halamanProduct.halamanProduct);

apiRouter.get("/admin/product/add", controllers.api.v1.halamanProduct.halamanTambahProduct);

apiRouter.post("/admin/product/add", controllers.api.v1.halamanProduct.createProduct);

apiRouter.get("/admin/product/edit/:id", controllers.api.v1.halamanProduct.halamanEditProduct);

apiRouter.post("/admin/product/edit/:id", controllers.api.v1.halamanProduct.updatedProduct);

apiRouter.post(
    "/login",
    controllers.api.v1.adminController.login
);
apiRouter.post("/register",
    controllers.api.v1.adminController.createAdmin
);

apiRouter.get("/users",
    controllers.api.v1.adminController.list
);

// categories-api
apiRouter.get("/categories",
    controllers.api.v1.categoriesControllers.list
);

apiRouter.get(
    "/categories/:id",
    controllers.api.v1.categoriesControllers.show
);

apiRouter.post("/categories",
    controllers.api.v1.categoriesControllers.create
);

apiRouter.put("/categories/:id",
    controllers.api.v1.categoriesControllers.update
);

apiRouter.delete(
    "/categories/:id",
    controllers.api.v1.categoriesControllers.delete
);

// orders api
apiRouter.get("/orders",
    controllers.api.v1.ordersControllers.list
);

apiRouter.get(
    "/orders/:id",
    controllers.api.v1.ordersControllers.show
);

apiRouter.post("/orders",
    controllers.api.v1.ordersControllers.create
);

apiRouter.put("/orders/:id",
    controllers.api.v1.ordersControllers.update
);

apiRouter.delete(
    "/orders/:id",
    controllers.api.v1.ordersControllers.delete
);

//products api
apiRouter.get(
    "/products/:id",
    controllers.api.v1.productControllers.showProduct
);

apiRouter.get(
    "/categories/products/:categoryId",
    controllers.api.v1.productControllers.showProductCategories
);

apiRouter.post("/products",
    controllers.api.v1.productControllers.create
);

apiRouter.put("/products/:id",
    controllers.api.v1.productControllers.update
);

apiRouter.delete(
    "/products/:id",
    controllers.api.v1.productControllers.delete
);

apiRouter.get("/products",
    controllers.api.v1.productControllers.list
);



// apiRouter.get(
//     "/api/v1/admin",
//     controllers.api.v1.adminControllers.authorize,
//     controllers.api.v1.adminControllers.list
// );
// apiRouter.put(
//     "/api/v1/admin/:id",
//     controllers.api.v1.adminControllers.authorize,
//     controllers.api.v1.adminControllers.update
// );

/**
 * TODO: Implement your own API
 *       implementations
 */

apiRouter.get("/api/v1/errors", () => {
    throw new Error("The Industrial Revolution and its consequences have been a disaster for the human race.");
});

apiRouter.use(controllers.api.main.onLost);
apiRouter.use(controllers.api.main.onError);

module.exports = apiRouter;