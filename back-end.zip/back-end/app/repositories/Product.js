const { Product } = require("../models");

module.exports = {
    create(createArgs) {
        return Product.create(createArgs);
    },
    update(id, updateArgs) {
        return Product.update(updateArgs, {
            where: {
                id,
            }
        });
    },
    delete(id) {
        return Product.destroy(id);
    },
    find(id) {
        return Product.findOne({
            where: {
                id,
            },
        });
    },

    findAll(args) {
        return Product.findAll(args);
    },

    getTotalProduct(args) {
        return Product.count(args);
    },
}