const adminServices = require("../../../services/adminServices");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const secretKey = "secret";

const SALT = 10;

function encryptPassword(password) {
    return new Promise((resolve, reject) => {
        bcrypt.hash(password, SALT, (err, encryptedPassword) => {
            if (!!err) {
                reject(err);
                return;
            }

            resolve(encryptedPassword);
        });
    });
}

function checkPassword(encryptedPassword, password) {
    return new Promise((resolve, reject) => {
        bcrypt.compare(password, encryptedPassword, (err, isPasswordCorrect) => {
            if (!!err) {
                reject(err);
                return;
            }

            resolve(isPasswordCorrect);
        });
    });
}

function createToken(payload) {
    return jwt.sign(payload, process.env.JWT_SIGNATURE_KEY || "Rahasia", {
        expiresIn: "12h", // it will be expired after 120 hours
    });
}

const createAdmin = async(req, res) => {
    const { emailAdmin, userName, namaAdmin, noHP } = req.body;
    const password = await encryptPassword(req.body.password);
    adminServices.create({
            namaAdmin,
            emailAdmin: emailAdmin,
            userName,
            noHP,
            password: password,
        })
        .then((user) => {
            res.status(201).json({
                status: "Success",
                message: "User Successfully Registered!",
                data: user
            });
        }).catch((err) => {
            res.status(400).json({
                status: "FAIL",
                message: err.message,
            });
        });

    // const hashedPassword = await bcrypt.hash(req.body.password, 10);
    // const admin = {
    //     namaAdmin: req.body.namaAdmin,
    //     emailAdmin: req.body.emailAdmin,
    //     noHP: req.body.noHP,
    //     userName: req.body.userName,
    //     password: hashedPassword,
    // };
    // try {
    //     await adminServices.create(admin);
    //     res.status(201).json({
    //         message: "Admin Created",
    //         data: admin,
    //     });
    // } catch (error) {
    //     res.status(400).send(error);
    // }
};

const login = async(req, res) => {
    const email = req.body.emailAdmin;
    const password = req.body.password;

    const user = await adminServices.login(email)

    if (!user) {
        res.status(404).json({ message: "Email tidak ditemukan" });
        return;
    }
    const isPasswordCorrect = await checkPassword(
        user.password,
        password
    );

    if (!isPasswordCorrect) {
        res.status(401).json({ message: "Password salah!" });
        return;
    }

    const token = createToken({
        id: user.id,
        email: user.emailAdmin,
        role: user.role,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
    });

    res.status(200).json({
        statusLogin: "Berhasil",
        id: user.id,
        email: user.email,
        role: user.role,
        token, // Kita bakal ngomongin ini lagi nanti.
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
    });

};

const list = async(req, res) => {
    adminServices
        .list()
        .then(({ data, count }) => {
            res.status(200).json({
                status: "OK",
                data: { users: data },
                meta: { total: count },
            });
        })
        .catch((err) => {
            res.status(400).json({
                status: "FAIL",
                message: err.message,
            });
        });

}

const halamanLogin = async(req, res, next) => {
    res.render('login', {
        title: 'Halaman Login'
    });
}

const halamanRegister = async(req, res, next) => {
    res.render("register", {
        title: 'Halaman Register'
    });
}

const halamanAwal = async(req, res, next) => {
    res.render("index");
}

const homeView = async(req, res, next) => {
    res.render('home', {
        title: 'Halaman Dashboard'
    })
}


module.exports = {
    login,
    createAdmin,
    list,
    halamanLogin,
    halamanRegister,
    homeView,
    halamanAwal
};