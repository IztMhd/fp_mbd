const ordersServices = require("../../../services/ordersServices");

module.exports = {
    create(req, res) {
        ordersServices
            .create(req.body)
            .save()
            .then((orders) => {
                res.status(201).json({
                    status: "OK",
                    data: orders,
                });
            })
            .catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    list(req, res) {
        ordersServices
            .list()
            .then(({ data, count }) => {
                res.status(200).json({
                    status: "OK",
                    data: { orders: data },
                    meta: { total: count },
                });
            })
            .catch((err) => {
                res.status(400).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    update(req, res) {
        ordersServices
            .update(req.params.id, req.body)
            .then((orders) => {
                res.status(200).json({
                    status: "OK",
                    orders: orders,
                });
            })
            .catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },

    delete(req, res) {
        ordersServices.delete({
                where: {
                    id: req.params.id
                }
            })
            .then(() => {
                res.status(200).json({
                    status: "OK",
                })
            }).catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    show(req, res) {
        ordersServices
            .get(req.params.id)
            .then((orders) => {
                res.status(200).json({
                    status: "OK",
                    data: orders,
                });
            })
            .catch((err) => {
                res.status(422).json({
                    status: "FAIL",
                    message: err.message,
                });
            });
    },
    createPage(req, res) {
        productServices
            .then(() => {
                res.render('addCategories', {
                    title: 'Halaman Tambah Cars'
                });
            })
            .catch((error) => {
                res.status(404).json({
                    message: error.message,
                })
            })
    },
};