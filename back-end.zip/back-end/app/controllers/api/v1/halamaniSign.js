const adminServices = require("../../../services/adminServices");

const login = async(req, res) => {
    try {
        const email = req.body.emailAdmin;
        const password = req.body.password;
        console.log(email);

        const user = await adminServices.login(email)

        if (!user) {
            res.status(404).json({ message: "Email tidak ditemukan" });
            return;
        }
        const isPasswordCorrect = await checkPassword(
            user.password,
            password
        );

        if (!isPasswordCorrect) {
            res.status(401).json({ message: "Password salah!" });
            return;
        }

        const token = createToken({
            id: user.id,
            email: user.emailAdmin,
            role: user.role,
            createdAt: user.createdAt,
            updatedAt: user.updatedAt,
        });

        res.status(200).json({
            statusLogin: "Berhasil",
            id: user.id,
            email: user.email,
            role: user.role,
            token, // Kita bakal ngomongin ini lagi nanti.
            createdAt: user.createdAt,
            updatedAt: user.updatedAt,
        });
        res.redirect('/admin/categories')
    } catch (error) {
        res.status(404).json({
            message: error.message,
        })
    }
};

module.exports = {
    login
}