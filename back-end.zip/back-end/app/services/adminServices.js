const Admins = require("../repositories/Admins");

module.exports = {
    create(requestBody) {
        return Admins.create(requestBody);
    },

    update(id, requestBody) {
        return Admins.update(id, requestBody);
    },
    login(requestBody) {
        return Admins.login(requestBody);
    },

    delete(id) {
        return Admins.delete(id);
    },

    async list() {
        try {
            const users = await Admins.findAll();
            const userCount = await Admins.getTotalUser();

            return {
                data: users,
                count: userCount,
            };
        } catch (err) {
            throw err;
        }
    },

    get(id) {
        return Admins.find(id);
    },
};