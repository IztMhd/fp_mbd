const Orders = require("../repositories/Orders");

module.exports = {
    create(requestBody) {
        return Orders.create(requestBody);
    },

    update(id, requestBody) {
        return Orders.update(id, requestBody);
    },

    delete(id) {
        return Orders.delete(id);
    },

    async list(args) {
        try {
            const orders = await Orders.findAll(args);
            const ordersCount = await Orders.getTotalOrders(args);

            return {
                data: orders,
                count: ordersCount,
            };
        } catch (err) {
            throw err;
        }
    },

    get(id) {
        return Orders.find(id);
    },
};